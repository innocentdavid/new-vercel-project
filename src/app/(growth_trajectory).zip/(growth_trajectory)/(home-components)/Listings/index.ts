import Listings from "./Listings";

export default Listings;
